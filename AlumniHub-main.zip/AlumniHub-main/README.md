# AlumniHub
AlumniHub is a comprehensive and user-friendly platform designed to facilitate the efficient management and organization of alumni data. Built as a full-stack application, this project utilizes React.js for the frontend and Spring Boot for the backend, ensuring a seamless user experience and performance
